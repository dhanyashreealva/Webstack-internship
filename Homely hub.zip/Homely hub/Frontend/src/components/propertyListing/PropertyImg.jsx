import React from 'react'

const PropertyImg = () => {
    const [isModalOpen,setIsModalOpen]=useState(false);

    const handleShowAllPhotos=()=>{
        setIsModalOpen
    }
  return (

    <div>
      
    </div>
  )
}

export default PropertyImg
