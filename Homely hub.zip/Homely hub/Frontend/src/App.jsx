import "./App.css";
import Main from "./components/home/Main";

function App() {
  return (
    <div className="App">
     <Main/>
    </div>
  );
}

export default App;
